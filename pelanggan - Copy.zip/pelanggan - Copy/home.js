document.addEventListener('DOMContentLoaded', () => {
    console.log("Home Page Loaded");
    // Logika scroll halus untuk menu navigasi
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });
});